from enum import Enum


class ModulStatus(Enum):

    #Enum für den Status eines Moduls, z.B. ob es bestanden, nicht bestanden oder in Bearbeitung ist
    GEPLANT = "GEPLANT"
    LAUFEND = "LAUFEND"
    ABGESCHLOSSEN = "ABGESCHLOSSEN"
