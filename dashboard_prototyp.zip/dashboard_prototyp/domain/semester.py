from typing import List
from .modul import Modul

# Klasse für Semester, enthält Nummer und Liste von Modulen (Komposition: Semester besteht aus Modulen)

class Semester:
    def __init__(self, nummer: int):
        self.nummer = nummer
        # Komposition: Semester besteht aus mehreren Modulen
        self.module: List[Modul] = []

    def modul_hinzufuegen(self, modul: Modul) -> None:
        self.module.append(modul)

    def __str__(self) -> str:
        zeilen = [f"Semester {self.nummer}:"]
        if not self.module:
            zeilen.append(" (keine Module)")
            return "\n".join(zeilen)

        for m in self.module:
            status = m.status.value

            if m.pruefungsleistung is None:
                pl_text = "keine Prüfungsleistung"
            else:
                pl_text = f"Note {m.pruefungsleistung.endnote} am {m.pruefungsleistung.datum}"

            zeilen.append(
                f" - {m.titel} ({m.ects} ECTS) - Status: {status} - {pl_text}"
            )

        return "\n".join(zeilen)
