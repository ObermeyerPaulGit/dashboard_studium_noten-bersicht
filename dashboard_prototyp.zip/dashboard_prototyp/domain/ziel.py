from abc import ABC, abstractmethod

class Ziel(ABC):
    #Abstrakte Basisklasse für alle Ziele. Jedes Ziel muss prüfen können ob es erreicht wurde

    def __init__(self, name: str): 
        self.name = name

    @abstractmethod
    def ist_erreicht(self) -> bool: 
        #Muss in Unterklassen implementiert werden, um zu prüfen ob das Ziel erreicht ist
        raise NotImplementedError
    
class NotendurchschnittsZiel(Ziel):
    # Ziel: Aktueller Notendurchschnitt soll <= zielwert sein

    def __init__ (self, aktueller_schnitt: float, zielwert: float):
        super().__init__("NotendurchschnittsZiel")
        self.aktueller_schnitt = aktueller_schnitt
        self.zielwert = zielwert

    def ist_erreicht(self) -> bool: 
        return self.aktueller_schnitt <= self.zielwert
    
class StudiendauerZiel(Ziel):
   # Ziel: aktuelles Semster soll <= ziel_semester sein

   def __init__(self, aktuelles_semester: int, ziel_semester: int): 
       super().__init__("Studiendauer")
       self.aktuelles_semester = aktuelles_semester
       self.ziel_semester = ziel_semester

   def ist_erreicht(self) -> bool:
        return self.aktuelles_semester <= self.ziel_semester
   
