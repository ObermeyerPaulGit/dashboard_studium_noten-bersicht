from dataclasses import dataclass
from typing import Optional
from modulstatus import ModulStatus
from .pruefungsleistung import Pruefungsleistung  

#dataclass für Modul, enthält Titel, ECTS, Status und optionale Prüfungsleistung

@dataclass
class Modul: 
    titel: str
    ects: int
    status: ModulStatus

    #Aggregation 0..1: Pruefungsleistung ist optional, da ein Modul auch ohne Pruefungsleistung existieren kann
    pruefungsleistung: Optional[Pruefungsleistung] = None

