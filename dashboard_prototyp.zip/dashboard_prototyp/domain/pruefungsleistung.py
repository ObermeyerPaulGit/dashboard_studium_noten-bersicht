from dataclasses import dataclass

#dataclass für Prüfungsleistung, enthält Endnote und Datum der Prüfung, sowie Methode zur Bestandsprüfung

@dataclass
class Pruefungsleistung:
    endnote: float
    datum   : str

    def __post_init__(self) -> None:

        # Validierung der Note
        if not (1.0 <= self.endnote <= 5.0):
            raise ValueError("Endnote muss zwischen 1.0 und 5.0 liegen.")
        
    def ist_bestanden(self) -> bool: 
        # Abgeleitete Information: bestanden ist nicht gespeichert sondern wird berechnet 
        return self.endnote < 4.0