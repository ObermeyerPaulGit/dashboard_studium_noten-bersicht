from typing import List
from datetime import datetime
from .semester import Semester
from .ziel import Ziel


class Studiengang:
    def __init__(self, name: str, ziel_semester: int):
        self.name = name
        self.ziel_semester = ziel_semester

        # Komposition
        self.semester: List[Semester] = []

        # Ziele (Aggregation / Assoziation)
        self.ziele: List[Ziel] = []

        # Neue Felder
        self.aktuelles_semester: int = 1
        self.monat_abgeschlossen: int = 0
        self.aktuelles_modul: str = ""

        # Zeitstempel der letzten Speicherung
        self.letzte_aktualisierung: str | None = None

    def semester_hinzufuegen(self, semester: Semester) -> None:
        self.semester.append(semester)

    def ziel_hinzufuegen(self, ziel: Ziel) -> None:
        self.ziele.append(ziel)

    def gesamt_ects(self) -> int:
        ects = 0
        for semester in self.semester:
            for modul in semester.module:
                ects += modul.ects
        return ects

    def notendurchschnitt(self) -> float | None:
        noten = []
        for semester in self.semester:
            for modul in semester.module:
                if modul.pruefungsleistung is not None:
                    noten.append(modul.pruefungsleistung.endnote)

        if not noten:
            return None

        return sum(noten) / len(noten)

    def verbleibende_semester(self) -> int:
        return max(0, self.ziel_semester - self.aktuelles_semester)

    def setze_letzte_aktualisierung(self) -> None:
        jetzt = datetime.now()
        self.letzte_aktualisierung = jetzt.strftime("%Y-%m-%d %H:%M:%S")