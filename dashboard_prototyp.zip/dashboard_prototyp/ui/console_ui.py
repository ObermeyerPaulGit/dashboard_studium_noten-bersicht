from modulstatus import ModulStatus
from domain.modul import Modul
from domain.pruefungsleistung import Pruefungsleistung


class ConsoleUI:
    def _red(self, text: str) -> str:
        return f"\033[31m{text}\033[0m"

    def _green(self, text: str) -> str:
        return f"\033[32m{text}\033[0m"

    def _bold(self, text: str) -> str:
        return f"\033[1m{text}\033[0m"

    def _ziel_status_text(self, erreicht: bool) -> str:
        return self._green("Ja") if erreicht else self._red("Nein")

    def _progress_bar(self, current: int, total: int, width: int = 20) -> str:
        if total <= 0:
            total = 1
        ratio = max(0.0, min(1.0, current / total))
        filled = int(ratio * width)
        return "[" + ("#" * filled) + ("-" * (width - filled)) + "]"

    def menue(self) -> str:
        print("\nWas möchtest du tun?")
        print("1) Dashboard anzeigen")
        print("2) Prüfungsleistung zu Modul hinzufügen/ändern")
        print("3) Semester hinzufügen")
        print("4) Modul hinzufügen")
        print("5) Einstellungen (Studiengang/Zielsemester/aktuelles Semester/Monatsziel/momentanes Modul)")
        print("6) Löschen (Semester/Modul/Prüfungsleistung)")
        print("7) Speichern")
        print("8) Alles zurücksetzen")
        print("9) Beenden")
        return input("Auswahl (1-9): ").strip()

    def zeige_dashboard(self, sg) -> None:
        print("\n==== STUDIEN DASHBOARD ====")
        print(f"Studiengang: {sg.name}")
        print(f"Zielsemester: {sg.ziel_semester}")

        # Aktueller Stand (letzte Speicherung)
        if getattr(sg, "letzte_aktualisierung", None):
            print(f"Letzte Aktualisierung: {sg.letzte_aktualisierung}")
        else:
            print("Letzte Aktualisierung: (noch nie gespeichert)")

        ects = sg.gesamt_ects()
        print(f"Gesamt-ECTS: {ects}")

        schnitt = sg.notendurchschnitt()
        print(f"Notendurchschnitt: {schnitt:.2f}" if schnitt is not None else "Notendurchschnitt: -")

        print("\n==== ZIELE ====")

        # Ziel 1: Studiendauer
        aktuelles_sem = sg.aktuelles_semester
        rest_sem = sg.verbleibende_semester()
        bar = self._progress_bar(aktuelles_sem, sg.ziel_semester, width=24)

        print("\nZiel 1: Studiendauer")
        print(f"Fortschritt: {bar}  {aktuelles_sem}/{sg.ziel_semester} Semester")
        print(f"Verbleibende Semester: {rest_sem}")
        ziel1_erreicht = aktuelles_sem <= sg.ziel_semester
        print("Ziel erreicht?", self._ziel_status_text(ziel1_erreicht))

        # Ziel 2: Notendurchschnitt
        print("\nZiel 2: Notendurchschnitt")
        if schnitt is None:
            print(self._bold("Aktueller Schnitt: -"))
            print("Ziel <= 2,5")
            print("Ziel erreicht?", self._ziel_status_text(False))
        else:
            print(self._bold(f"Aktueller Schnitt: {schnitt:.2f}"))
            print("Ziel <= 2,5")
            ziel2_erreicht = schnitt <= 2.5
            print("Ziel erreicht?", self._ziel_status_text(ziel2_erreicht))

        # Ziel 3: Monatsziel
        print("\nZiel 3: Monatliches Modulziel")
        abgeschlossen = 1 if sg.monat_abgeschlossen else 0
        print(self._bold(f"{abgeschlossen} / 1 Modul pro Monat abgeschlossen"))

        aktuelles_modul = sg.aktuelles_modul.strip() or "(nicht gesetzt)"
        print(f"Momentanes Modul: {aktuelles_modul}")

        ziel3_erreicht = abgeschlossen >= 1
        print("Ziel erreicht?", self._ziel_status_text(ziel3_erreicht))

        # Semesterübersicht
        print("\n--- Semesterübersicht ---")
        if not sg.semester:
            print("(noch keine Semester vorhanden)")
        else:
            for semester in sg.semester:
                print(semester)

        print("==========================")

    def frage_semester_nummer(self) -> int | None:
        text = input("Semester-Nummer (Enter zum Abbrechen): ").strip()
        if text == "":
            return None
        if not text.isdigit():
            print("Ungültige Nummer.")
            return None
        return int(text)

    def frage_semester_index(self, sg) -> int | None:
        if not sg.semester:
            print("Keine Semester vorhanden.")
            return None

        print("\nSemester auswählen:")
        for i, sem in enumerate(sg.semester, start=1):
            print(f"{i}) Semester {sem.nummer}")

        text = input("Nummer (Enter zum Abbrechen): ").strip()
        if text == "":
            return None
        if not text.isdigit():
            return None

        idx = int(text) - 1
        if idx < 0 or idx >= len(sg.semester):
            return None

        return idx

    def frage_modul_daten(self) -> Modul | None:
        titel = input("Modultitel (Enter zum Abbrechen): ").strip()
        if titel == "":
            return None

        ects_text = input("ECTS: ").strip()
        if not ects_text.isdigit():
            print("Ungültige ECTS.")
            return None

        print("Status wählen:")
        print("1) GEPLANT")
        print("2) LAUFEND")
        print("3) ABGESCHLOSSEN")

        s = input("Auswahl: ").strip()
        mapping = {"1": ModulStatus.GEPLANT, "2": ModulStatus.LAUFEND, "3": ModulStatus.ABGESCHLOSSEN}
        if s not in mapping:
            return None

        return Modul(titel, int(ects_text), mapping[s])

    def frage_modul_auswahl(self, sg):
        sem_idx = self.frage_semester_index(sg)
        if sem_idx is None:
            return None

        semester = sg.semester[sem_idx]
        if not semester.module:
            print("Keine Module vorhanden.")
            return None

        print("\nModul auswählen:")
        for i, m in enumerate(semester.module, start=1):
            print(f"{i}) {m.titel} ({m.ects} ECTS) - {m.status.value}")

        text = input("Nummer (Enter zum Abbrechen): ").strip()
        if text == "" or not text.isdigit():
            return None

        idx = int(text) - 1
        if idx < 0 or idx >= len(semester.module):
            return None

        return sem_idx, idx

    def frage_pruefungsleistung(self) -> Pruefungsleistung | None:
        note = input("Endnote (1.0 - 5.0) (Enter zum Abbrechen): ").strip()
        if note == "":
            return None

        datum = input("Datum (YYYY-MM-DD): ").strip()

        try:
            return Pruefungsleistung(float(note), datum)
        except Exception as e:
            print("Fehler:", e)
            return None

    def frage_einstellungen(
        self, aktueller_name: str, aktuelles_zielsemester: int
    ) -> tuple[str, int, int, int, str] | None:
        print("\nEinstellungen (Enter = Wert beibehalten, außer aktuelles Semester):")

        name = input(f"Studiengang-Name [{aktueller_name}]: ").strip()
        if name == "":
            name = aktueller_name

        ziel_text = input(f"Zielsemester [{aktuelles_zielsemester}]: ").strip()
        if ziel_text == "":
            zielsemester = aktuelles_zielsemester
        else:
            if not ziel_text.isdigit():
                print("Ungültiges Zielsemester.")
                return None
            zielsemester = int(ziel_text)

        sem_text = input("Aktuelles Semester (z.B. 4) (Enter=Abbruch): ").strip()
        if sem_text == "":
            return None
        if not sem_text.isdigit():
            print("Ungültiges aktuelles Semester.")
            return None
        aktuelles_semester = int(sem_text)

        a = input("Hast du diesen Monat 1 Modul abgeschlossen? (j/n): ").strip().lower()
        if a not in ("j", "n"):
            print("Ungültige Eingabe.")
            return None
        abgeschlossen = 1 if a == "j" else 0

        aktuelles_modul = input("Momentanes Modul (Enter=leer): ").strip()
        return name, zielsemester, aktuelles_semester, abgeschlossen, aktuelles_modul

    def frage_neuen_studiengang(self) -> tuple[str, int] | None:
        print("\nNeuen Studiengang anlegen (Reset):")
        name = input("Studiengang-Name (Enter=Abbruch): ").strip()
        if name == "":
            return None

        ziel_text = input("Zielsemester (z.B. 7): ").strip()
        if not ziel_text.isdigit():
            print("Ungültiges Zielsemester.")
            return None

        return name, int(ziel_text)

    def loesch_menue(self) -> str:
        print("\nWas möchtest du löschen?")
        print("1) Semester löschen")
        print("2) Modul löschen")
        print("3) Prüfungsleistung löschen (Note entfernen)")
        print("4) Abbrechen")
        return input("Auswahl (1-4): ").strip()

    def frage_semester_loeschen_index(self, sg) -> int | None:
        if not sg.semester:
            print("Keine Semester vorhanden.")
            return None

        print("\nSemester löschen – Auswahl:")
        for i, sem in enumerate(sg.semester, start=1):
            print(f"{i}) Semester {sem.nummer}")

        text = input("Nummer (Enter zum Abbrechen): ").strip()
        if text == "" or not text.isdigit():
            return None

        idx = int(text) - 1
        if idx < 0 or idx >= len(sg.semester):
            return None

        return idx

    def bestaetigung(self, text: str) -> bool:
        antwort = input(f"{text} (j/n): ").strip().lower()
        return antwort == "j"