import json
from pathlib import Path
from typing import Any, Dict, Optional

from modulstatus import ModulStatus

from domain.studiengang import Studiengang
from domain.semester import Semester
from domain.modul import Modul
from domain.pruefungsleistung import Pruefungsleistung


class StudiengangRepository:
    def __init__(self, dateipfad: str = "studiengang.json"):
        self.dateipfad = Path(dateipfad)

    def speichern(self, studiengang: Studiengang) -> None:
        studiengang.setze_letzte_aktualisierung()
        daten = self._studiengang_to_dict(studiengang)

        with self.dateipfad.open("w", encoding="utf-8") as f:
            json.dump(daten, f, ensure_ascii=False, indent=2)

    def laden(self) -> Studiengang:
        if not self.dateipfad.exists():
            raise FileNotFoundError(f"Datei nicht gefunden: {self.dateipfad}")

        with self.dateipfad.open("r", encoding="utf-8") as f:
            daten = json.load(f)

        return self._dict_to_studiengang(daten)

    def _studiengang_to_dict(self, sg: Studiengang) -> Dict[str, Any]:
        return {
            "name": sg.name,
            "ziel_semester": sg.ziel_semester,
            "aktuelles_semester": sg.aktuelles_semester,
            "monat_abgeschlossen": sg.monat_abgeschlossen,
            "aktuelles_modul": sg.aktuelles_modul,
            "letzte_aktualisierung": sg.letzte_aktualisierung,
            "semester": [self._semester_to_dict(s) for s in sg.semester],
        }

    def _semester_to_dict(self, s: Semester) -> Dict[str, Any]:
        return {
            "nummer": s.nummer,
            "module": [self._modul_to_dict(m) for m in s.module],
        }

    def _modul_to_dict(self, m: Modul) -> Dict[str, Any]:
        return {
            "titel": m.titel,
            "ects": m.ects,
            "status": m.status.name,
            "pruefungsleistung": self._pruefungsleistung_to_dict(m.pruefungsleistung),
        }

    def _pruefungsleistung_to_dict(
        self, pl: Optional[Pruefungsleistung]
    ) -> Optional[Dict[str, Any]]:
        if pl is None:
            return None
        return {"endnote": pl.endnote, "datum": pl.datum}

    def _dict_to_studiengang(self, daten: Dict[str, Any]) -> Studiengang:
        sg = Studiengang(name=daten["name"], ziel_semester=int(daten["ziel_semester"]))

        sg.aktuelles_semester = int(daten.get("aktuelles_semester", 0))
        sg.monat_abgeschlossen = int(daten.get("monat_abgeschlossen", 0))
        sg.aktuelles_modul = str(daten.get("aktuelles_modul", ""))

        sg.letzte_aktualisierung = daten.get("letzte_aktualisierung")

        for s_dict in daten.get("semester", []):
            sg.semester_hinzufuegen(self._dict_to_semester(s_dict))

        return sg

    def _dict_to_semester(self, daten: Dict[str, Any]) -> Semester:
        s = Semester(nummer=int(daten["nummer"]))
        for m_dict in daten.get("module", []):
            s.modul_hinzufuegen(self._dict_to_modul(m_dict))
        return s

    def _dict_to_modul(self, daten: Dict[str, Any]) -> Modul:
        status_enum = ModulStatus[daten["status"]]
        m = Modul(
            titel=str(daten["titel"]),
            ects=int(daten["ects"]),
            status=status_enum,
        )
        m.pruefungsleistung = self._dict_to_pruefungsleistung(daten.get("pruefungsleistung"))
        return m

    def _dict_to_pruefungsleistung(
        self, daten: Optional[Dict[str, Any]]
    ) -> Optional[Pruefungsleistung]:
        if daten is None:
            return None
        return Pruefungsleistung(endnote=float(daten["endnote"]), datum=str(daten["datum"]))