from domain.semester import Semester
from modulstatus import ModulStatus
from domain.studiengang import Studiengang

# Controller für Dashboard-Logik (verbindet Domain, UI und Repository)

class DashboardController:
    def __init__(self, studiengang, ui, repo):
        self.studiengang = studiengang
        self.ui = ui
        self.repo = repo

# Hilfsmethode zum Zurücksetzen des Studiengangs (z.B. bei Neustart), erstellt neuen Studiengang mit gegebenem Namen und Zielsemester
    def _reset_studiengang(self, name: str, ziel_semester: int) -> None:
        self.studiengang = Studiengang(name=name, ziel_semester=ziel_semester)

# Hauptlogik: Endlosschleife mit Menü, reagiert auf Benutzereingaben, aktualisiert Domain-Objekte und speichert bei Bedarf
    def run(self) -> None:
        while True:
            auswahl = self.ui.menue()

# Je nach Auswahl werden verschiedene Aktionen ausgeführt, z.B. Dashboard anzeigen, Modul hinzufügen, Einstellungen ändern, etc.
# Auswahl 1: Dashboard anzeigen, hier wird die Methode der UI aufgerufen, die den aktuellen Zustand des Studiengangs anzeigt
            if auswahl == "1":
                self.ui.zeige_dashboard(self.studiengang)

# Auswahl 2: Prüfungsleistung hinzufügen/ändern, hier wird zuerst das Modul ausgewählt, dann die Prüfungsleistung abgefragt und gespeichert
            elif auswahl == "2":
                auswahl_tuple = self.ui.frage_modul_auswahl(self.studiengang)
                if auswahl_tuple is None:
                    continue

                sem_index, modul_index = auswahl_tuple
                pl = self.ui.frage_pruefungsleistung()
                if pl is None:
                    continue

                modul = self.studiengang.semester[sem_index].module[modul_index]
                modul.pruefungsleistung = pl
                modul.status = ModulStatus.ABGESCHLOSSEN
                print("Prüfungsleistung gespeichert. Status -> ABGESCHLOSSEN.")

# Auswahl 3: Semester hinzufügen, hier wird die Semester-Nummer abgefragt und ein neues Semester-Objekt zum Studiengang hinzugefügt
            elif auswahl == "3":
                nr = self.ui.frage_semester_nummer()
                if nr is None:
                    continue
                self.studiengang.semester_hinzufuegen(Semester(nr))
                print("Semester hinzugefügt.")

# Auswahl 4: Modul hinzufügen, hier wird zuerst das Semester ausgewählt, dann die Moduldaten abgefragt und zum Semester hinzugefügt
            elif auswahl == "4":
                sem_idx = self.ui.frage_semester_index(self.studiengang)
                if sem_idx is None:
                    continue

                modul = self.ui.frage_modul_daten()
                if modul is None:
                    continue

                self.studiengang.semester[sem_idx].modul_hinzufuegen(modul)
                print("Modul hinzugefügt.")

# Auswahl 5: Einstellungen ändern, hier werden alle relevanten Daten abgefragt und im Studiengang-Objekt aktualisiert
            elif auswahl == "5":
                res = self.ui.frage_einstellungen(self.studiengang.name, self.studiengang.ziel_semester)
                if res is None:
                    continue

                name, zielsemester, aktuelles_semester, abgeschlossen, aktuelles_modul = res
                self.studiengang.name = name
                self.studiengang.ziel_semester = zielsemester
                self.studiengang.aktuelles_semester = aktuelles_semester
                self.studiengang.monat_abgeschlossen = abgeschlossen
                self.studiengang.aktuelles_modul = aktuelles_modul
                print("Einstellungen aktualisiert.")

# Auswahl 6: Semester/Modul/Prüfungsleistung löschen, hier gibt es ein Untermenü, in dem zuerst die Art der Löschung ausgewählt wird, dann das zu löschende Objekt und schließlich die Bestätigung
            elif auswahl == "6":
                sub = self.ui.loesch_menue()

                if sub == "1":
                    idx = self.ui.frage_semester_loeschen_index(self.studiengang)
                    if idx is None:
                        continue

                    sem_num = self.studiengang.semester[idx].nummer
                    if self.ui.bestaetigung(f"Semester {sem_num} wirklich löschen?"):
                        del self.studiengang.semester[idx]
                        print("Semester gelöscht.")

                elif sub == "2":
                    auswahl_tuple = self.ui.frage_modul_auswahl(self.studiengang)
                    if auswahl_tuple is None:
                        continue

                    sem_index, modul_index = auswahl_tuple
                    modul = self.studiengang.semester[sem_index].module[modul_index]

                    if self.ui.bestaetigung(f"Modul '{modul.titel}' wirklich löschen?"):
                        del self.studiengang.semester[sem_index].module[modul_index]
                        print("Modul gelöscht.")

                elif sub == "3":
                    auswahl_tuple = self.ui.frage_modul_auswahl(self.studiengang)
                    if auswahl_tuple is None:
                        continue

                    sem_index, modul_index = auswahl_tuple
                    modul = self.studiengang.semester[sem_index].module[modul_index]

                    if modul.pruefungsleistung is None:
                        print("Dieses Modul hat keine Prüfungsleistung.")
                        continue

                    if self.ui.bestaetigung(f"Prüfungsleistung von '{modul.titel}' wirklich löschen?"):
                        modul.pruefungsleistung = None
                        print("Prüfungsleistung gelöscht.")
                else:
                    continue

# Auswahl 7: Daten speichern, hier wird die Methode des Repositories aufgerufen, die den aktuellen Studiengang in einer Datei speichert
            elif auswahl == "7":
                self.repo.speichern(self.studiengang)
                print("Gespeichert.")

# Auswahl 8: Alles löschen und von vorne beginnen, hier wird zuerst eine Bestätigung eingeholt, dann die Daten für einen neuen Studiengang abgefragt und schließlich der Studiengang zurückgesetzt
            elif auswahl == "8":
                if not self.ui.bestaetigung("Wirklich ALLES löschen und von vorne beginnen?"):
                    continue

                res = self.ui.frage_neuen_studiengang()
                if res is None:
                    continue

                name, ziel_semester = res
                self._reset_studiengang(name, ziel_semester)
                self.repo.speichern(self.studiengang)
                print("Alles zurückgesetzt (und gespeichert).")

# Auswahl 9: Programm beenden, hier wird zuerst eine Bestätigung eingeholt, ob vor dem Beenden gespeichert werden soll, dann ggf. gespeichert und schließlich die Schleife mit break verlassen
            elif auswahl == "9":
                if self.ui.bestaetigung("Vor dem Beenden speichern?"):
                    self.repo.speichern(self.studiengang)
                    print("Gespeichert.")
                print("Programm beendet.")
                break

            else:
                print("Ungültige Auswahl.")