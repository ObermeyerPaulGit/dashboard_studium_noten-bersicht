from ui.console_ui import ConsoleUI
from controller.dashboard_controller import DashboardController
from persistence.studiengang_repository import StudiengangRepository
from domain.studiengang import Studiengang


def main() -> None:

    # Repository (Dateispeicherung)
    repository = StudiengangRepository("studiengang.json")

    # UI
    ui = ConsoleUI()

    # Versuch zu laden
    try:
        studiengang = repository.laden()
        print("Studiengang aus Datei geladen.")
    except FileNotFoundError:
        print("Keine Datei gefunden — neuer Studiengang wird erstellt.")
        studiengang = Studiengang(
            "Angewandte Künstliche Intelligenz",
            ziel_semester=7
        )

    # Controller (verbindet alles)
    controller = DashboardController(
        studiengang,
        ui,
        repository
    )

    controller.run()

if __name__ == "__main__":
    main()
